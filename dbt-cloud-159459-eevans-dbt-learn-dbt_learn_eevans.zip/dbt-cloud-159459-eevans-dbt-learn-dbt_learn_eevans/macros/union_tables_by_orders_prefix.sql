{{
    union_tables_by_prefix(
        database = dbt-tutorial
        )
}}